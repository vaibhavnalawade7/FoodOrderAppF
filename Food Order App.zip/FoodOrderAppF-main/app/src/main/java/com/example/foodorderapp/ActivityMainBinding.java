package com.example.foodorderapp;

public class ActivityMainBinding {
}
